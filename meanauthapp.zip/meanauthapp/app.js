const express = require('express');
const path  = require('path');
const bodyParser = require('body-parser');
const cors = require('cors');
const passport = require('passport');
const mongoose =  require('mongoose');
const config = require('./config/database');
const Users = require('./server/api/User-api');
const User = require('./server/models/user-model');
mongoose.connect(config.database);

mongoose.connection.on('connected',()=>{
    console.log("connected to databse"+config.database);
});

mongoose.connection.on('error',(err)=>{
    console.log("connected to databse"+err);
});



 
// Users=mongoose.model("users",{
// 		name:String,
// 		email:String,
// 		DOB:String,
// 		dept:String,
// 		gender:String,
// 		age:Number});
 
 // here we have a create file code..... 

//  var userObj = {
// 	name:"arjun bhai",
// 	email:"abc@gmail.com",
// 	DOB:"22/11/2016",
// 	dept:"cse",
// 	gender:"male",
// 	age:11
// };


// var user = new User(userObj);

// // console.log(user);
// user.save(function(err,res){
// 	//res.json(result);
// 	console.log(res);
// 	});


//create file ends here... 



// Users.remove({_id:"58b9d8fb66b88405800c8cfc"},function(err,removed){
// 	console.log("removed from database");
// 	//res.send("removed the user");
// 	});


// Users.update({_id:"58b9bf239236164978276f02"},userObj,null,function(err,response){
// 	//res.send("updated the user");
// 	console.log("hey updated");
// 	});


// this code for retrieve of data....

	// Users.find({},function(err,result){
	// console.log(result);	
	// //res.json(result);
    
	// });

	
// fetching is done
//Users.createUser(userObj);
//Users.getAllUser();

const app = express();

mongoose.Promise=global.Promise;

const users = require('./routes/users');

const port = 8080;

//cors middle ware
app.use(cors());

//set static folder
app.use(express.static(path.join(__dirname, 'public')));

//body parser middleware
app.use(bodyParser.json());

app.use('/users', users);

// index route
app.get('/', (req,res) => {
    res.send('Invalid endpoint');
});

//
app.route("/message").post(Users.createUser);
app.route("/update").put(Users.updateUser);
app.route("/delete").delete(Users.deleteUser);
app.get("/employee",Users.getAllUser);

//start server
app.listen(port,()=>{
    console.log("server connected to port"+port);
});

