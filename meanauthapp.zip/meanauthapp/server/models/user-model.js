const mongoose = require('mongoose');
const userSchema = mongoose.Schema({
    name:String,
    email:String,
    DOB:String,
    dept:String,
    gender:String,
    age:Number
});


// const personSchema = mongoose.Schema({
//     puppy:String,
//     tommy:String,
//     baby:String
// });


const User = module.exports = mongoose.model('User',userSchema);

//const Person = module.exports = mongoose.model('Person',personSchema);
//  User.find({},function(err,result){
//         //res.send("update the user");
//         console.log(result);
//     });

// module.exports.getUserById = function(id, callback) {
//     User.findById(id, callback);
// }


// module.exports.getUserByName = function(username, callback) {
//     const query = {username: username}
//     User.findOne(query, callback);
// }

// module.exports.addUser = function(newUser,callback) {
//     bcrypt.getSalt(10, (err, salt)=>{
//         bcrypt.hash(newUser.password,salt,(err, salt)=>{
//             if(err) throw err;
//             newUser.password = hash;
//             newUser.save(callback);
//         });
//     });
// }