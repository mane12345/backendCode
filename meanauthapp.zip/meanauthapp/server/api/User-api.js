var User = require("../models/user-model.js");
//var Person = require("../models/user-model.js");

module.exports.createUser = function(req, res) {
   console.log(req.body);
    var user = new User(req.body);
    // console.log("hey");
    // console.log(req.body);
    user.save(function(err,result){
        if(err) {
          res.json(err); 
        }
        // console.log("hey save");
        res.json(result);
       //console.log(res);
      
    });
}

module.exports.updateUser = function(req,res) {
    console.log("id"+req.body._id);
    User.update({_id:req.body._id}, req.body, null, function(err,result){
       // res.send("update the user");
       console.log("hey bupdate");
       res.json(result);
    });
}

module.exports.deleteUser = function(req,res) {
    console.log("hey  dekete");
    console.log(req.body._id);
    User.remove({_id:req.body._id}, function(err,result){
        console.log("removed");
         res.json(result);
    });
}

module.exports.getAllUser = function(req,res) {
    User.find({},function(req,resu){
       // res.send("all the data");
        
        console.log("hello");
        console.log(resu);
        res.json(resu);
    });
}


